package com.anudip.springdemo;

import org.springframework.stereotype.Component;

@Component("tester")
public class Tester implements Employee{

	@Override
	public void works() {

		System.out.println("Tester is Testing the  app");
		
	}

}
