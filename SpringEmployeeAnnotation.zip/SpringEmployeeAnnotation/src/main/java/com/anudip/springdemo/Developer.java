package com.anudip.springdemo;

import org.springframework.stereotype.Component;

@Component("developer")
public class Developer implements Employee{

	@Override
	public void works() {
		System.out.println("Developer is developing the app");
		
	}

}
