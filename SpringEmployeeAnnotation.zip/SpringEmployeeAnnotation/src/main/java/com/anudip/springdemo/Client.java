package com.anudip.springdemo;

public interface Client {

	public void project();
}
