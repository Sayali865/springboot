package com.anudip.springdemo;

public interface Employee {
	
	public void works();

}
