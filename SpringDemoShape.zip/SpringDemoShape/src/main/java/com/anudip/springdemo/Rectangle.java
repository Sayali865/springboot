package com.anudip.springdemo;

public class Rectangle implements Shape{

	private String color;
	
	public Rectangle(String color) {
		super();
		this.color = color;
	}

	@Override
	public void draw() {

		System.out.println("Painter is drawing" +color+ "rectangle");
		
	}

	
}
