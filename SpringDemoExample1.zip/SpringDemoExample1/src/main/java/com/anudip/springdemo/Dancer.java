package com.anudip.springdemo;

public class Dancer implements Performer {

	@Override
	public void perform() {

    System.out.println("Dancer is dancing on a song");
		
	}

}
