package com.anudip.springdemo;

public interface Performer {

	public void perform();
}
