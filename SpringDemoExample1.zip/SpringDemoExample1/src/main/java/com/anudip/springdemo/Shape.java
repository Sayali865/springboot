package com.anudip.springdemo;

public interface Shape {
    
	public void draw();
}
