package com.springdemo;


public class Coffee implements HotDrink {
	
	
	@Override
	public void prepareHotDrink() {
		
		System.out.println(" preparing cofee");

		
		
	}

}
