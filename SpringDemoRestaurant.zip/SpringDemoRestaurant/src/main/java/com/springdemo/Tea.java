package com.springdemo;


public class Tea implements HotDrink {


	@Override
	public void prepareHotDrink() {
 
		 System.out.println("preparing hot drink");
		
	}

	
}
