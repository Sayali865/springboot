package com.springdemo;

public interface HotDrink {
	
	public void prepareHotDrink();
	

}
